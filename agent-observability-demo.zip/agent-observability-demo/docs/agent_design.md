# Agent Design Notes

## Goal

Build a small telemetry investigation agent that demonstrates production-aware thinking.

## Key design decisions

### Tool instead of skill

Telemetry queries are implemented as tools because they represent external actions with structured inputs and outputs.

### Skill-style workflow

The investigation process can be written as a skill/workflow:

1. Read incident summary.
2. Query metrics, logs, and traces.
3. Compare signals.
4. Separate correlation from causation.
5. Report uncertainty.
6. Suggest safe next steps.

### Failure mode

The main failure mode is false causality: the agent may see a deploy and a latency spike at the same time and blame the deploy without enough evidence.

### Mitigation

The agent must:

- use more than one telemetry signal,
- mark uncertain conclusions clearly,
- avoid irreversible actions without confirmation,
- run regression evals against known ambiguous incidents.
